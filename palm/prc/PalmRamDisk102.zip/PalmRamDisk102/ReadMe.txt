Palm RAM Disk v1.0
Copyright (c) 2002 by HandWatch, Inc.
Written by Mark Chao-Kuang Yang

http://www.handwatch.com
email: handwatch@handwatch.com

-----------
Quick Start
-----------
1. Install both RamDiskDrv.prc and RamDiskPnl.prc to your Palm device using HotSync. When ask for a soft reset, select Reset button.
2. After soft reset, it would ask whether to format the external device. It is to initialize the content of the RAM disk. Select OK button.

3. Soon after format is done, goto Launcher. There will be a new disk device under the category menu.


-----------------------------------
To Install new version of RAM Disk:
-----------------------------------
On Palm:
1. Goto RAM Disk Prefs Panel.
2. Select Menu->Unmount.

On Desktop:
1. Use Palm Install Tool to add all Palm files.
2. Perform HotSync.


-------------
To Uninstall:
-------------
1. Goto RAM Disk Prefs Panel.
2. Select Menu->Unmount.
3. Delete RAM Disk from launcher.


-------------------
System Requirement:
-------------------
PalmOS 3.5 and above with Expansion Manager and Virtual File System (VFS) capability to support memory card slot device.
Acer s10 is not supported due to hardware incompatibility.


------------------
Special Thanks To:
------------------
Andreas C. Bauer (bauer@mac.com) for icon design.



