Thank you for your interest in NoviiRemote Deluxe software for Palm OS!

This is a complete full-functioned version of the NoviiRemote Deluxe
software, version 3.7 (build 2007.12.17b, IRv68, released in December
2007), ready for installation for your Palm OS based handheld via a
Windows, Mac or Linux computer.

 * NEW in version 3.7:  Palm Centro supported

1. Installation
===============

IMPORTANT. If you already have the previous version of NoviiRemote
Deluxe installed on your handheld, do not remove it. Just install the
new version ABOVE the previous one.

Step 1. Enter the Install folder. You will find there three prc and
one pdb file. Synchronize them to your Palm device.

Step 2. If you are going to install the software at the first time,
enter the start_profile folder and synchronize six start-up
configuration files which you will find in that folder.

Step 3. If your Palm device has the low resolution screen 160*160 (e.g.
Palm Z22, Treo 600, Zire 21, Zire 31, m130, m515, etc.) enter the 
 low_res folder. You will find there two skin files developed for the 
low resolution screen. Install those two files ABOVE the files
installed at the previous steps.

TIP. If you are concerned about memory requirements, you may install 
the software to the SD-card. Synchronize all the files into PALM / 
launcher directory.

2. User Guide.
=============

NRD_3.7_Palm.pdf. This is a User Guide in PDF format. You will the
manual in the User Guide folder. 

3. Getting the activation key
=============================

This is a complete full-functioned version. However without an 
activation key, the application will stop its work in ten days after
the very first launch on your handheld.

To resume work of NoviiRemote Deluxe you need an activation key. If
you've already ordered the application, you have got the activation
key too.

If for some reason you have not got the activation key, you should
register NoviiRemote Deluxe by sending the proof of purchase to our
support team. In response you'll receive the activation key.

4. Contacts
===========
NoviiMedia

Web: www.novii.tv/palm/deluxe
E-mail: service@novii.com 

5. To purchase please refer to www.novii.tv/palm/deluxe
==============

December 2007
The NoviiMedia Team
