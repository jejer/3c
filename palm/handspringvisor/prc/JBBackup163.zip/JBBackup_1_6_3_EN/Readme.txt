			         JBBackup
			       Version 1.6.3
		           HandFort Solutions
			      April 3, 2002



Installation:

Install JBBackup.prc and zLib.prc and the apropriate plugin on your device. 
Each of the plugin's directory contains instructions on how to backup/store the files so that they will be accessible after a battery failure/hard reset. Multiple plugins can be used on the same device.

If you have any difficulties with the installation, please contact us
at support@handfort.com.

If you are using JackFlash or plan to use the native Flash plugin you will need to run JackSafe in order to be able to recover your data in case of a battery failure or hard reset.

VFS devices - Palm m505, m500, m515, m125, m130, i705, S series, N series and T series Clie devices, HandEra 330

	JBBackup.prc
	sysZLib.prc
	VFSPlugin.prc


Devices with Flash and no 3rd party Flash software (JackFlash or FlashPro)

	JackSafe.prc
	JBInstall.prc
	
Note: If you encounter a message telling you to run RemoveFP, then you will need to 
use the RemoveFP utility before you will be able to use JBBackup.  See 
RemoveFP.txt in the RemoveFP directory for more details.


Devices with JackFlash - Palm m505, m500, m515, i705, IIIc, IIxe, IIIx, III, Vx, V, Symbol SPT, S series, N series and T series Clie devices

	JBBackup.prc
	sysZLib.prc
	JFPlugin.prc

Devices with FlashPro - Palm m505, m500, IIIc, IIxe, IIIx, III, Vx, V, Symbol SPT, TRGPro

	JBBackup.prc
	sysZLib.prc
	FPPlugin.prc

Handspring devices with Flash/Hagiwara/ThinModule+ Springboard

	JBBackup.prc
	sysZLib.prc
	VisorPlugin.prc

Handspring devices with FlashPlus/Innopocket/MatchBox Springboard & Kopsis' FA libraries

	JBBackup.prc
	sysZLib.prc
	VisorCF.prc

Devices with axxPac module - Palm IIIx, IIIxe

	JBBackup.prc
	sysZLib.prc
	axxPac.prc

TRGPro or Handera CF 

	JBBackup.prc
	sysZLib.prc
	TRGCFPlugin.prc


Support:

Should you have any questions or concerns, please contact us at
support@handfort.com.  We want to ensure that JBBackup exceeds your expectations
and that you are fully satisfied with your purchase.


This archive contains:

Readme.txt		this file
Changes.txt		the change history of the application
License.txt		the end-user license
JBBInstall.prc	the JBBackup installer fort he native Flash plugin
JBBackup.pdf	the JBBackup user manual
Plugins		each of the directories contains a plugin and a readme file with
 			instructions on how to install/configure the plugin.

Please read all the documentation and the software license before using this software.
