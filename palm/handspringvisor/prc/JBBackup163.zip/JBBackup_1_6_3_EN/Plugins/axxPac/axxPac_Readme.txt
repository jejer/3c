	Installing on a Palm IIIx or IIIxe with the axxpac adapter instaled


Install the following files in RAM or Flash:

JBBackup.prc
SysZLib.prc
axxPacPlugin.prc


Install the axxPac shell/drivers in Flash  using JackFlash or FlashPro. Use the axxPack shell to move the files to the SmartMedia card or install the files in Flash.