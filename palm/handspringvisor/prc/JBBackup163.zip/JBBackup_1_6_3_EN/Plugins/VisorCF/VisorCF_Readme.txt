	Manually installing on a Visor with a CF adapter.

Install the following files onto your Visor:

JBBackup.prc
SysZLib.prc
VisorCF.prc


Note: You need Kopsis' FALib.prc (v1.2 or greater) to be 
installed on your device before the VisorCF plugin becomes
active. 
This file is NOT part of JBBackup's package and can be 
obtained separately from http://www.kopsisengineering.com

Once they are in RAM, use the FAFileMover application to copy
them to the CF.