	Installing on VFS compatible device (m50x, Sony Clie)

Install the following files onto your device:

JBBackup.prc
SysZLib.prc
VFSPlugin.prc

Once they are in RAM, use a file mover of yoru choice to 
copy them to the external storage. The copies will be 
used in case of a battery failure or hard reset. 


