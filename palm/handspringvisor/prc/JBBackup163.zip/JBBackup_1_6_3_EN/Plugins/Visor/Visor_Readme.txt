	Installing on a Visor with the Flash SpringBoard, Hagiwara Modules or ThinModem+.


Install the following files onto your Visor:

JBBackup.prc
SysZLib.prc
VisorPlugin.prc

Use the FileMover application to move them to the SpringBoard.