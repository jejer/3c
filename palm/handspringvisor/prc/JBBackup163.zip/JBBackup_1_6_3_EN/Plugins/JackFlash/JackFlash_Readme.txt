	Installing on a Palm with JackFlash.

JBBackup only works with JackFlash 2.02 or greater.
Please ensure that you have the latest version.

Install the following files onto your Palm:

JBBackup.prc
SysZLib.prc
JFPlugin.prc

Once they are in RAM, use JackFlash to move JBBackup
and SysZLib to Flash.  Then use JBBackup to make 
backups of JackFlash and JFPlugin. 

IMPORTANT:  You must install JackSafe!  This will
allow your backups to survive a battery failure.
