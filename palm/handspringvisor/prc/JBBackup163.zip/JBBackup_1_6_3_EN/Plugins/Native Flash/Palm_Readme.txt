If you have a Palm without JackFlash or FlashPro, then
you must use the installer to install JBBackup. There 
is no manual method of installing. 

IMPORTANT:  You must install JackSafe!  This will
allow your backups to survive a battery failure.