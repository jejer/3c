	Installing on a TRGPro/Handera 330 device with CF.

Install the following files onto your device:

JBBackup.prc
SysZLib.prc
TRGCFPlugin.prc

Once they are in RAM, use the CFPro/CardPro application to move
them to the CFCard.

On TRGPro devices, if you have FlashPro installed on your device,
you can insatll the files in the Flash area as well.