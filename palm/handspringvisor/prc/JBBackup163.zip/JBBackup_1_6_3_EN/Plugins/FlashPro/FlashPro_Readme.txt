	Installing on a Palm/TRGPro with FlashPro.

Install the following files onto your Palm:

JBBackup.prc
SysZLib.prc
FPPlugin.prc


Once they are in RAM, use FlashPro to move them 
to the Flash.  You should also make a backup of
FlashPro using JBBackup.
