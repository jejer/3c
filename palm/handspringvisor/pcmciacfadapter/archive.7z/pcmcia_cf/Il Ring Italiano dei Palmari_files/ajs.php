(function(){
var s = "<"+"script type=\"text/javascript\" src=\"http://a170.casalemedia.com/pcreative?au=2&c=20EFAD&pcid=4C7820121F00&pr=55&r=4C782012&s=25014&t=55399235&u=XzZiYjZiMTAwLVdON19fX19fX19fX19f&m=bcb4be467fa2ae5105e511c43c60c095&wp=1A&cp=0.178&aid=AE7EDEA0551EA3AD&tid=0&dm=64&n=webring.org&epr=d87ab36340\"><"+"/script>\n";
s += "<"+"div id=\'beacon_d87ab36340\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"http://cat.ny.us.criteo.com/delivery/lg.php?cppv=1&cpp=y6YSaXxUR1BXbUFDdUpER2NYZGlKS1lpUFhXUFZWN2owYUdkMGlMbVphY0dzdTNBSmJaR0w1ZCtWc09XYmMvTXltZXhTMWVGVWZVeVZmVkFRcjJEbk5aVlhLS1hzRUw4K1Z5YzE5YWJ4Sm1oRlJ5OUtGc01XSXZ0TWNvWS9CMEZNL0pDUEx3cTNHbTJ4SC9jR0JOVVBhNk8xUEpKRFI1SU4wTGJ3YlFyWERYSHFoMXA2WnRKNGV4OEE4V2ZDclBBYnpyY0haVGEvRHgxUUdTMUVSTXJmVEZYRE93PT18\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
