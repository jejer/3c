			      JackSprat
			     Version 3.1
		     Brayder Technologies Inc.
			  September 6, 2005


Installation:

Use the Install Tool to install JackSprat.prc on your Palm.  After your 
next HotSync, this program will be available on your Palm device.

If you are using FlashPro, please uninstall it before using JackSprat. 
You can use FPUninst.prc from the FlashPro distribution, or RemoveFP.prc from
the JackSprat distribution.


MSMount Users:
MSMount MUST be disabled in order to correctly backup the ROM with
JackSprat.  Please diasable it before using JackSprat.



Support:

Should you have any questions or concerns, please contact us at
support@brayder.com.  We want to ensure that JackSprat exceeds your expectations
and that you are fully satisfied with your purchase.



Please read all the documentation and the software license before using this software.
