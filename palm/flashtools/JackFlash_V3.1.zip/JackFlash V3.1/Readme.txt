			      JackFlash
			     Version 3.1
		     Brayder Technologies Inc.
			  September 6, 2005


Installation:

Use the Install Tool to install JackFlash.prc and optionally one of
JackSafe.prc or FlashEnable.prc on your PalmOS device.  After your 
next HotSync, these programs will be  available for use.

JackFlash.prc is the main JackFlash application and is necessary for all
Flash operations.

JackSafe is an optional utility that adds support in the operating system
to restore the contents of Flash after a battery failure or a Hard reset.
Without this utility the contents of Flash will be hidden after a battery
failure, until you are able to run JackFlash again. JackSafe works with 
all devices supported by JackFlash except for Sony OS5 devices and Acer
devices.

FlashEnable can be used instead of JackSafe on Sony OS5 devices and Acer
devices. FlashEnable can be copied to a expansion card, where it can be
used after a hard reset. Running FlashEnable after a hard reset or battery
failure will restore items stored in Flash.

We suggest that you use JackSafe to add the Flash restore support to your Palm.
See JackSafe.txt for more details.


Existing JackFlash Users:

The new version can be installed directly over your existing copy.  There is no
need to disable or delete the existing installation.  If you have already 
installed JackSafe, then you do not need to install it again.


FlashPro Detected:

If you encounter a "FlashPro detected" message when you try to use JackFlash,
then you will need to use the RemoveFP utility before you will be able to
use JackFlash.  See the readme.txt in the RemoveFP directory for more details.


Flash Compatiblity:

Applications which need to be "Enabled" may not work correctly with JackFlash.
Please avoid placing these programs into Flash.  Exceptions to this rule include
Launchers such as Launch 'em and Handscape.  These applications are safe to 
place in Flash. For more details on Flash compatibility, see the 
"Flash Compatibility" section of the User Guide.



Support:

Should you have any questions or concerns, please contact us at
support@brayder.com.  We want to ensure that JackFlash exceeds your expectations
and that you are fully satisfied with your purchase.


This archive contains:

Readme.txt	this file
JackSafe.txt	details about the JackSafe utility
Changes.txt	the change history of the application
License.txt	the end-user license
JackSafe.prc	the JackSafe application
JackFlash.prc	the JackFlash application to install on your Palm device
JackFlash.pdf	the JackFlash user manual

Please read all the documentation and the software license before using this software.
