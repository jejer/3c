
SiS 7012 PCI Audio Driver Setup Readme File
-------------------------------------------

To install Windows 95/98/Me/NT4/Win2000/WinXP/WinServer2003/WinXP and WinServer2003 x64 Edition drivers, please run SETUP.EXE in this directory;
To uninstall Windows 95/98/Me/NT4/Win2000/WinXP/WinServer2003/WinXP and WinServer2003 x64 Edition drivers, please run Control_Panel->
Add/Remove_Program->SiS Audio Driver

To install drivers for other O.S, please see README file under each
driver directory.

SETUP.EXE Automatically installs WDM or VxD driver for Windows 95/98 base on
the O.S version:
  -WDM driver is installed for Windows 98SE and
  -VxD is installed for Windows 98OEM (first edition, 4.10.1998) and
Windows 95.  

To force installing VxD driver for Windows 98SE, please run
"SETUP.EXE -vxd" using Windows Start->Run


To update the driver, just run SETUP.EXE directly. SETUP will overwrite
the old driver with the current one.


Setup Switch Description
------------------------

You can run "Setup -sw" for desired operation. For example,
run "Setup -s" for silent installing driver.
Or add a line "CmdLine=-s" in the [Startup] section of file Setup.ini
then just run Setup without any switch.
The switches are

 -vxd
  force installing VxD driver on Windows 98SE;

 -ar
  install AudioRack;

 -s
  silent install, *NOTE* this switch should be put as the last one
 
 -s -f2c:\test.log
  build log file in silent install mode
  The log file is like below:
    [InstallShield Silent]
     Version=v5.00.000
     File=Log File
    [Application]
     Name=SiS 7012 PCI Audio Driver
     Version=0.91.00
     Company=Silicon Integrated Systems Corporation
    [ResponseResult]
     ResultCode=0

    The list of the ResultCode defined in InstallShied 5.1:
     -0 Success.
     -1 General error.
     -2 Invalid mode.
     -3 Required data not found in the Setup.iss file.
     -4 Not enough memory available.
     -5 File does not exist.
     -6 Cannot write to the response file.
     -7 Unable to write to the log file.
     -8 Invalid path to the InstallShield Silent response file.
     -9 Not a valid list type (string or number).
     -10 Data type is invalid.
     -11 Unknown error during setup.
     -12 Dialogs are out of order.
     -51 Cannot create the specified folder.
     -52 Cannot access the specified file or folder.
     -53 Invalid option selected  



Win2000/WinXP/WinServer2003 Setup Limitation
------------------------
Please do not use SILENT INSTALL after remove audio device. Please restart computer after remove audio device then doing silent install.


Change History
--------------

[Setup/Uninstall]
~111
-Upgrade setup package from Install Shield 5.1 to Install Shield 7
-Update unAuRack.exe in AudiRack folder to meet the
 upgrade of Install Shield Package

~update setup.ins to correct error message in Win98 split INF files 
 driver installiation.

~110.06
-update setup.ins and me_inst.exe to meet the change of split INF files
 in Win98/WinME drivers.

~110.00
-update waitwnd.exe to solve the asking "a3d.dll" path problem

~107.04
-update setup.ins, fix the problem that audio hotkey function doesn't work

~106.06
-Update setup.ins, fix the problem that in Win2000 will setup SiSAudUt.exe -vxd problem
-Update setup.ini, change the parameters SiSAudUt_NT5_Install to SiSAudHk_NT5_Install and SiSAudUt_NOTNT5_Install to SiSAudHk_NOTNT5_Install

~106.05
-Update setup.ins to accept parameter from setup.ini to select the recording quality level
-Update setup.ini; add section "SETUP_PARAMETER" and parameter "Recording_Quality". 
 Set Recording_Quality to 0 ==> Do Not change the current system default recording quality setting
 Set Recording_Quality to 1 ==> Set the current system default recording quality to CD quality
 Set Recording_Quality to 2 ==> Set the current system default recording quality to Radio quality
 Set Recording_Quality to 3 ==> Set the current system default recording quality to Telephone quality

~106.04
-Update setup.ins to change the preset of recording quality to CD Quality
-Update setup.ini, in section APP_INST_PAR, remove the parameter "SiSAudUt_Install" and add two parameters "SiSAudUt_VxDNT4_Install" to indicate whether to install SiSAudUt.exe in NT4 or using Vxd drivers and "SiSAudUt_WDM_Install" to indicate whether to install SiSAudUt.exe while using WDM drivers.
-Update waitwnd.exe
-Update SiSAudUt.exe to support set channels from Direct Sound
-Update setup.ini, in section APP_INST_PAR, remove the parameter "SiSAudHk_Install" and add two parameters "SiSAudUt_NT5_Install" to indicate whether to install SiSAudHk.exe in Win2000/WinXP and "SiSAudUt_NOTNT5_Install" to indicate whether to install SiSAUdHk.exe in the rest of the OS

~106.00
-Update setup.ins to meet the chage of the update for SiSAudUt.exe 

~105.02
-Update setup.ins to correct the setup error of SiSAudUt.exe in Win98 OEM
 Edition

~1.05.01
-Add SiSAudHk.exe for adjust volume control mute, volume up and volume down using preset hotkeys.
 For Installing SiSAudUt.exe, Plesase set the parameter "SiSAudHk_Install" to 1 in the
 [APP_INST_PAR] section of setup.ini; otherwise set the parameter to 0
-Update SiSAudUt.exe
-Update UndrvApp.exe
-update setup.ins for installing SiSAudKe.exe

~1.04
-Add SiSAudUt.exe for vxd drivers to set it's midi sample file, and for wdm drivers to
 set the configurations of speakers and SPDIF.
 For Installing SiSAudUt.exe, please set the parameter "SiSAudUt_Install" to 1 in the
 [APP_INST_PAR] section of setup.ini; otherwise set the parameter to 0
-update UnDrvApp.exe
-update setup.ins for installing SiSAudUt.exe



Play .mid file under NT4/VxD
-----------------------
-1.Download DLS or SF2 file from WWW
-2.Use SiSAudUt.exe for NT4 drivers to set it's midi sample file(DLS or SF2)
-3.If you want to change midi sample file, repeat step 1 and 2

