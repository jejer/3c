
   SiS Sound Card Drivers Installation for Windows NT 4.0
   ------------------------------------------------------

   Before proceeding, be sure you have installed the sound card into your
   system. Since Windows NT4 does not support Plug-N-Play, you will need
   to install the drivers manually using the following steps:

   To install the SiS Sound Card Drivers for NT 4.0, you can run Setup.exe
   located in the upper directory or do the followings:

   0. If you have previously installed the driver for SiS sound card,
      you must remove the driver and restart your computer before installing
      the driver. Please use Start->Settings->Control Panel->Multimedia
      to remove the driver.

   1. Click on Start->Settings->Control Panel.

   2. Double-click on the Multimedia icon, then select the Devices tab. 

   3. Click on the Add button, then select Unlisted or Updated Driver 
      from the list box. Click on OK. 

   4. You will now be prompted to insert or locate the vendor-provided 
      driver disk. Enter the path to this directory.

   5. A dialog box titled Add Unlisted or Updated Driver will appear.
      Make sure the sound card driver is selected, then click OK.

   6. Once the drivers have been copied to your system, you will be 
      prompted to reboot. Go ahead and reboot at this time.


Tips and Other Useful Information
---------------------------------
1. It is recommended that Windows NT4 users update their system with the
   most recent Service Pack release.

Play .mid file under NT4
-----------------------
-1.Download DLS or SF2 file from WWW
-2.Use SiSAudUt.exe for NT4 drivers to set it's midi sample file(DLS or SF2)
-3.If you want to change midi sample file, repeat step 1 and 2
